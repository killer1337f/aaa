"""Handling of LuaTools add/download flows and related utilities."""

from __future__ import annotations

import base64
import json
import os
import re
import threading
import time
import datetime
from typing import Any, Dict

import Millennium  # type: ignore

from api_manifest import load_api_manifest
from settings.manager import get_morrenus_api_key
from config import (
    APPID_LOG_FILE,
    LOADED_APPS_FILE,
    USER_AGENT,
    WEBKIT_DIR_NAME,
    WEB_UI_ICON_FILE,
    WEB_UI_JS_FILE,
)
from http_client import ensure_http_client
import httpx
from logger import logger
from paths import backend_path, public_path
from steam_utils import detect_steam_install_path, has_lua_for_app
from utils import count_apis, ensure_temp_download_dir, normalize_manifest_text, read_text, write_text

DOWNLOAD_STATE: Dict[int, Dict[str, Any]] = {}
DOWNLOAD_LOCK = threading.Lock()

# Cache for app names and infos to avoid repeated API calls
APP_NAME_CACHE: Dict[int, str] = {}
APP_NAME_CACHE_LOCK = threading.Lock()

APP_INFO_CACHE: Dict = {}
APP_INFO_CACHE_LOCK = threading.Lock()

# Rate limiting for Steam API calls
LAST_API_CALL_TIME = 0
API_CALL_MIN_INTERVAL = 0.3  # 300ms between calls to avoid 429 errors

# In-memory applist for fallback app name lookup
APPLIST_DATA: Dict[int, str] = {}
APPLIST_LOADED = False
APPLIST_LOCK = threading.Lock()
APPLIST_FILE_NAME = "all-appids.json"
APPLIST_URL = "https://applist.morrenus.xyz/"
APPLIST_DOWNLOAD_TIMEOUT = 300  # 5 minutes for large file

GAMES_DB_FILE_NAME = "games.json"
GAMES_DB_URL = "https://toolsdb.piqseu.cc/games.json"

# In-memory games database cache and lock (defined to avoid undefined variable)
GAMES_DB_DATA: Dict[int, Any] = {}
GAMES_DB_LOADED = False
GAMES_DB_LOCK = threading.Lock()


def _set_download_state(appid: int, update: dict) -> None:
    with DOWNLOAD_LOCK:
        state = DOWNLOAD_STATE.get(appid) or {}
        state.update(update)
        DOWNLOAD_STATE[appid] = state


def _get_download_state(appid: int) -> dict:
    with DOWNLOAD_LOCK:
        return DOWNLOAD_STATE.get(appid, {}).copy()


def _loaded_apps_path() -> str:
    return backend_path(LOADED_APPS_FILE)


def _appid_log_path() -> str:
    return backend_path(APPID_LOG_FILE)


def _fetch_app_name(appid: int) -> str:
    """Fetch app name with rate limiting and caching.
    
    Fallback order:
    1. In-memory cache
    2. Applist file (in-memory) - checked before web requests
    3. Steam API (web request as final resort)
    """
    global LAST_API_CALL_TIME

    # Check cache first
    with APP_NAME_CACHE_LOCK:
        if appid in APP_NAME_CACHE:
            cached = APP_NAME_CACHE[appid]
            if cached:  # Only return if not empty
                return cached

    # Check applist file before making web requests
    applist_name = _get_app_name_from_applist(appid)
    if applist_name:
        # Cache the result from applist
        with APP_NAME_CACHE_LOCK:
            APP_NAME_CACHE[appid] = applist_name
        return applist_name

    # Steam API as final resort (web request)
    # Rate limiting: calculate wait time and update timestamp atomically
    with APP_NAME_CACHE_LOCK:
        time_since_last_call = time.time() - LAST_API_CALL_TIME
        sleep_time = API_CALL_MIN_INTERVAL - time_since_last_call if time_since_last_call < API_CALL_MIN_INTERVAL else 0
        # Update timestamp now to reserve this slot (prevents race condition)
        LAST_API_CALL_TIME = time.time() + sleep_time

    if sleep_time > 0:
        time.sleep(sleep_time)

    client = ensure_http_client("LuaTools: _fetch_app_name")
    try:
        url = f"https://store.steampowered.com/api/appdetails?appids={appid}"
        logger.log(f"LuaTools: Fetching app name for {appid} from Steam API")
        resp = client.get(url, follow_redirects=True, timeout=10)
        logger.log(f"LuaTools: Steam API response for {appid}: status={resp.status_code}")
        resp.raise_for_status()
        data = resp.json()
        entry = data.get(str(appid)) or {}
        if isinstance(entry, dict):
            inner = entry.get("data") or {}
            name = inner.get("name")
            if isinstance(name, str) and name.strip():
                name = name.strip()
                # Cache the result
                with APP_NAME_CACHE_LOCK:
                    APP_NAME_CACHE[appid] = name
                return name
    except Exception as exc:
        logger.warn(f"LuaTools: _fetch_app_name failed for {appid}: {exc}")

    # Cache empty result to avoid repeated failed attempts
    with APP_NAME_CACHE_LOCK:
        APP_NAME_CACHE[appid] = ""
    return ""


def _fetch_app_info(appid: int) -> dict:
    """Fetch app info from steamcmd with caching.
    
    Fallback order:
    1. In-memory cache
    2. Steamcmd.net (request)
    """
    global LAST_API_CALL_TIME

    # Check cache first
    with APP_INFO_CACHE_LOCK:
        if appid in APP_INFO_CACHE:
            cached = APP_INFO_CACHE[appid]
            if cached:  # Only return if not empty
                return cached

    client = ensure_http_client("LuaTools: _fetch_app_info")
    try:
        url = f"https://api.steamcmd.net/v1/info/{appid}"
        logger.log(f"LuaTools: Fetching app info for {appid} from steamcmd.net")
        resp = client.get(url, follow_redirects=True, timeout=10)
        logger.log(f"LuaTools: steamcmd.net response for {appid}: status={resp.status_code}")
        resp.raise_for_status()

        data = resp.json().get("data", {})

        if isinstance(data, dict):
            root = data.get(str(appid), {})

            depots = root.get("depots", {})
            extended = root.get("extended", {})

            output = {
                "workshop_depot": depots.get("workshopdepot", 0),
                "dlc_list": extended.get("listofdlc", "")
            }

            # Cache the result
            with APP_INFO_CACHE_LOCK:
                APP_INFO_CACHE[appid] = output
            return output
    except Exception as exc:
        logger.warn(f"LuaTools: _fetch_app_info failed for {appid}: {exc}")

    # Cache empty result to avoid repeated failed attempts
    with APP_INFO_CACHE_LOCK:
        APP_INFO_CACHE[appid] = {}
    return {}


def _append_loaded_app(appid: int, name: str) -> None:
    try:
        path = _loaded_apps_path()
        lines = []
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                lines = handle.read().splitlines()
        prefix = f"{appid}:"
        lines = [line for line in lines if not line.startswith(prefix)]
        lines.append(f"{appid}:{name}")
        with open(path, "w", encoding="utf-8") as handle:
            handle.write("\n".join(lines) + "\n")
    except Exception as exc:
        logger.warn(f"LuaTools: _append_loaded_app failed for {appid}: {exc}")


def _remove_loaded_app(appid: int) -> None:
    try:
        path = _loaded_apps_path()
        if not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8") as handle:
            lines = handle.read().splitlines()
        prefix = f"{appid}:"
        new_lines = [line for line in lines if not line.startswith(prefix)]
        if len(new_lines) != len(lines):
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("\n".join(new_lines) + ("\n" if new_lines else ""))
    except Exception as exc:
        logger.warn(f"LuaTools: _remove_loaded_app failed for {appid}: {exc}")


def _log_appid_event(action: str, appid: int, name: str) -> None:
    try:
        stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        line = f"[{action}] {appid} - {name} - {stamp}\n"
        with open(_appid_log_path(), "a", encoding="utf-8") as handle:
            handle.write(line)
    except Exception as exc:
        logger.warn(f"LuaTools: _log_appid_event failed: {exc}")


def _preload_app_names_cache() -> None:
    """Pre-load all app names from loaded_apps, appidlogs, and applist files into memory cache."""
    # First, load from appidlogs.txt (historical records)
    try:
        log_path = _appid_log_path()
        if os.path.exists(log_path):
            with open(log_path, "r", encoding="utf-8") as handle:
                for line in handle.read().splitlines():
                    # Format: [ACTION - API_NAME] appid - name - timestamp
                    # Example: [ADDED - Sadie] 945360 - Among Us - 2024-01-15 14:05:04
                    # Or: [REMOVED] appid - name - timestamp
                    if "]" in line and " - " in line:
                        try:
                            # Extract content after the first ']'
                            parts = line.split("]", 1)
                            if len(parts) < 2:
                                continue

                            content = parts[1].strip()
                            # Split by " - " to get: appid, name, timestamp (max 3 parts)
                            content_parts = content.split(" - ", 2)

                            if len(content_parts) >= 2:
                                appid_str = content_parts[0].strip()
                                name = content_parts[1].strip()

                                # Try to parse appid
                                appid = int(appid_str)

                                # Skip "Unknown Game" or "UNKNOWN" entries
                                if name and not name.startswith("Unknown") and not name.startswith("UNKNOWN"):
                                    with APP_NAME_CACHE_LOCK:
                                        APP_NAME_CACHE[appid] = name
                        except (ValueError, IndexError):
                            continue
    except Exception as exc:
        logger.warn(f"LuaTools: _preload_app_names_cache from logs failed: {exc}")

    # Then, load from loaded_apps.txt (current state - overrides log if present)
    try:
        path = _loaded_apps_path()
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                for line in handle.read().splitlines():
                    if ":" in line:
                        parts = line.split(":", 1)
                        try:
                            appid = int(parts[0].strip())
                            name = parts[1].strip()
                            if name:
                                with APP_NAME_CACHE_LOCK:
                                    APP_NAME_CACHE[appid] = name
                        except (ValueError, IndexError):
                            continue
    except Exception as exc:
        logger.warn(f"LuaTools: _preload_app_names_cache from loaded_apps failed: {exc}")
    
    # Finally, load from applist file (as fallback source - doesn't override existing cache)
    # This ensures applist is available for lookups without web requests
    try:
        _load_applist_into_memory()
    except Exception as exc:
        logger.warn(f"LuaTools: _preload_app_names_cache from applist failed: {exc}")


def _get_loaded_app_name(appid: int) -> str:
    """Get app name from loadedappids.txt, with applist as fallback."""
    try:
        path = _loaded_apps_path()
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                for line in handle.read().splitlines():
                    if line.startswith(f"{appid}:"):
                        name = line.split(":", 1)[1].strip()
                        if name:
                            return name
    except Exception:
        pass
    
    # Fallback to applist if not found in loadedappids.txt
    return _get_app_name_from_applist(appid)


def _applist_file_path() -> str:
    """Get the path to the applist JSON file."""
    temp_dir = ensure_temp_download_dir()
    return os.path.join(temp_dir, APPLIST_FILE_NAME)


def _load_applist_into_memory() -> None:
    """Load the applist JSON file into memory for fast lookups."""
    global APPLIST_DATA, APPLIST_LOADED
    
    with APPLIST_LOCK:
        if APPLIST_LOADED:
            return
        
        file_path = _applist_file_path()
        if not os.path.exists(file_path):
            logger.log("LuaTools: Applist file not found, skipping load")
            APPLIST_LOADED = True  # Mark as loaded to avoid repeated checks
            return
        
        try:
            logger.log("LuaTools: Loading applist into memory...")
            with open(file_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
            
            if isinstance(data, list):
                count = 0
                for entry in data:
                    if isinstance(entry, dict):
                        appid = entry.get("appid")
                        name = entry.get("name")
                        if appid and name and isinstance(name, str) and name.strip():
                            APPLIST_DATA[int(appid)] = name.strip()
                            count += 1
                logger.log(f"LuaTools: Loaded {count} app names from applist into memory")
            else:
                logger.warn("LuaTools: Applist file has invalid format (expected array)")
            
            APPLIST_LOADED = True
        except Exception as exc:
            logger.warn(f"LuaTools: Failed to load applist into memory: {exc}")
            APPLIST_LOADED = True  # Mark as loaded to avoid repeated failed attempts


def _get_app_name_from_applist(appid: int) -> str:
    """Get app name from in-memory applist."""
    # Ensure applist is loaded
    if not APPLIST_LOADED:
        _load_applist_into_memory()
    
    with APPLIST_LOCK:
        return APPLIST_DATA.get(int(appid), "")


def _ensure_applist_file() -> None:
    """Download the applist file if it doesn't exist."""
    file_path = _applist_file_path()
    
    if os.path.exists(file_path):
        logger.log("LuaTools: Applist file already exists, skipping download")
        return
    
    logger.log("LuaTools: Applist file not found, downloading...")
    client = ensure_http_client("LuaTools: DownloadApplist")
    
    try:
        logger.log(f"LuaTools: Downloading applist from {APPLIST_URL}")
        resp = client.get(APPLIST_URL, follow_redirects=True, timeout=APPLIST_DOWNLOAD_TIMEOUT)
        logger.log(f"LuaTools: Applist download response: status={resp.status_code}")
        resp.raise_for_status()
        
        # Validate JSON format before saving
        try:
            data = resp.json()
            if not isinstance(data, list):
                logger.warn("LuaTools: Downloaded applist has invalid format (expected array)")
                return
        except json.JSONDecodeError as exc:
            logger.warn(f"LuaTools: Downloaded applist is not valid JSON: {exc}")
            return
        
        # Save to file
        with open(file_path, "w", encoding="utf-8") as handle:
            json.dump(data, handle)
        
        logger.log(f"LuaTools: Successfully downloaded and saved applist file ({len(data)} entries)")
    except Exception as exc:
        logger.warn(f"LuaTools: Failed to download applist file: {exc}")


def init_applist() -> None:
    """Initialize the applist system: download if needed, then load into memory."""
    try:
        _ensure_applist_file()
        _load_applist_into_memory()
    except Exception as exc:
        logger.warn(f"LuaTools: Applist initialization failed: {exc}")


def _games_db_file_path() -> str:
    """Get the path to the games database JSON file."""
    temp_dir = ensure_temp_download_dir()
    return os.path.join(temp_dir, GAMES_DB_FILE_NAME)


def _load_games_db_into_memory() -> None:
    """Load the games database JSON file into memory."""
    global GAMES_DB_DATA, GAMES_DB_LOADED
    
    with GAMES_DB_LOCK:
        if GAMES_DB_LOADED:
            return
        
        file_path = _games_db_file_path()
        if not os.path.exists(file_path):
            logger.log("LuaTools: Games DB file not found, skipping load")
            GAMES_DB_LOADED = True
            return
        
        try:
            logger.log("LuaTools: Loading Games DB into memory...")
            with open(file_path, "r", encoding="utf-8") as handle:
                GAMES_DB_DATA = json.load(handle)
            
            logger.log(f"LuaTools: Loaded Games DB ({len(GAMES_DB_DATA)} entries)")
            GAMES_DB_LOADED = True
        except Exception as exc:
            logger.warn(f"LuaTools: Failed to load Games DB: {exc}")
            GAMES_DB_LOADED = True


GAMES_DB_CACHE_MAX_AGE_SECONDS = 24 * 60 * 60  # 24 hours


def _is_games_db_cache_stale() -> bool:
    """Check if the games database cache file is older than 24 hours."""
    file_path = _games_db_file_path()
    if not os.path.exists(file_path):
        return True
    try:
        file_mtime = os.path.getmtime(file_path)
        age_seconds = time.time() - file_mtime
        return age_seconds > GAMES_DB_CACHE_MAX_AGE_SECONDS
    except Exception:
        return True


def _ensure_games_db_file() -> None:
    """Download the games database file if missing or stale (older than 24 hours)."""
    file_path = _games_db_file_path()

    # Skip download if file exists and is fresh
    if os.path.exists(file_path) and not _is_games_db_cache_stale():
        logger.log("LuaTools: Games DB cache is fresh, skipping download")
        return

    logger.log("LuaTools: Downloading Games DB (cache missing or stale)...")
    client = ensure_http_client("LuaTools: DownloadGamesDB")
    
    try:
        logger.log(f"LuaTools: Downloading Games DB from {GAMES_DB_URL}")
        resp = client.get(GAMES_DB_URL, follow_redirects=True, timeout=60)
        logger.log(f"LuaTools: Games DB download response: status={resp.status_code}")
        resp.raise_for_status()
        
        data = resp.json()
        
        with open(file_path, "w", encoding="utf-8") as handle:
            json.dump(data, handle)
        
        logger.log(f"LuaTools: Successfully downloaded Games DB")
    except Exception as exc:
        logger.warn(f"LuaTools: Failed to download Games DB: {exc}")


def init_games_db() -> None:
    """Initialize the games database: download if needed, then load into memory."""
    try:
        _ensure_games_db_file()
        _load_games_db_into_memory()
    except Exception as exc:
        logger.warn(f"LuaTools: Games DB initialization failed: {exc}")


def get_games_database() -> str:
    """Get the games database as JSON string."""
    if not GAMES_DB_LOADED:
        init_games_db()
    
    with GAMES_DB_LOCK:
        return json.dumps(GAMES_DB_DATA)


def fetch_app_name(appid: int) -> str:
    return _fetch_app_name(appid)

def fetch_app_info(appid: int) -> str:
    return json.dumps(_fetch_app_info(appid))



def _process_and_install_lua(appid: int, zip_path: str) -> None:
    """Process downloaded zip and install lua file into stplug-in directory."""
    import zipfile

    if _is_download_cancelled(appid):
        raise RuntimeError("cancelled")

    base_path = detect_steam_install_path() or Millennium.steam_path()
    target_dir = os.path.join(base_path or "", "config", "stplug-in")
    os.makedirs(target_dir, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as archive:
        names = archive.namelist()

        try:
            depotcache_dir = os.path.join(base_path or "", "depotcache")
            os.makedirs(depotcache_dir, exist_ok=True)
            for name in names:
                try:
                    if _is_download_cancelled(appid):
                        raise RuntimeError("cancelled")
                    if name.lower().endswith(".manifest"):
                        pure = os.path.basename(name)
                        data = archive.read(name)
                        out_path = os.path.join(depotcache_dir, pure)
                        with open(out_path, "wb") as manifest_file:
                            manifest_file.write(data)
                        logger.log(f"LuaTools: Extracted manifest -> {out_path}")
                except Exception as manifest_exc:
                    logger.warn(f"LuaTools: Failed to extract manifest {name}: {manifest_exc}")
        except Exception as depot_exc:
            logger.warn(f"LuaTools: depotcache extraction failed: {depot_exc}")

        candidates = []
        for name in names:
            pure = os.path.basename(name)
            if re.fullmatch(r"\d+\.lua", pure):
                candidates.append(name)

        if _is_download_cancelled(appid):
            raise RuntimeError("cancelled")

        chosen = None
        preferred = f"{appid}.lua"
        for name in candidates:
            if os.path.basename(name) == preferred:
                chosen = name
                break
        if chosen is None and candidates:
            chosen = candidates[0]
        if not chosen:
            raise RuntimeError("No numeric .lua file found in zip")

        data = archive.read(chosen)
        try:
            text = data.decode("utf-8")
        except Exception:
            text = data.decode("utf-8", errors="replace")

        processed_lines = []
        depots = { "ids": [] , "lines": {} }
        for line in text.splitlines(True):
            if re.match(r"^\s*setManifestid\(", line) and not re.match(r"^\s*--", line):
                line = re.sub(r"^(\s*)", r"\1--", line)
            processed_lines.append(line)
            if re.match(r"^\s*addappid\(", line) and not re.match(r"^\s*--", line):
                if (m := re.search(r"\d+", line)):
                    id = m.group()

                    depots["ids"].append(id)
                    if id not in depots["lines"]:
                        depots["lines"][id] = []
                    depots["lines"][id] = line
            
        processed_text = "".join(processed_lines)

        _set_download_state(appid, {"status": "installing"})
        dest_file = os.path.join(target_dir, f"{appid}.lua")
        if _is_download_cancelled(appid):
            raise RuntimeError("cancelled")
        with open(dest_file, "w", encoding="utf-8") as output:
            output.write(processed_text)
        logger.log(f"LuaTools: Installed lua -> {dest_file}")
        _set_download_state(appid, {"installedPath": dest_file})

        # Check .lua content
        try:
            if _is_download_cancelled(appid):
                raise RuntimeError("cancelled")
            
            info = _fetch_app_info(appid)
            
            # Workshop presence
            work_depot = str(info.get("workshop_depot", 0))
            if work_depot == "0":
                workshop_result = "No workshop for the game"
            else:
                # Checking if mentionned in addappid lines + if it includes a decryption key
                if work_depot in depots["ids"] and re.search(rf",\d+,[\"']", depots["lines"][work_depot].replace(" ", "")):
                    workshop_result = "Included"
                else:
                    workshop_result = "Missing"
            
            # Dlc listing
            dlc_result = { "included": [], "missing": [] }
            if info.get("dlc_list", "") != "":
                dlcs = info["dlc_list"].split(",")

                for dlc in dlcs:
                    if dlc in depots["ids"]:
                        dlc_result["included"].append(int(dlc))
                    else:
                        dlc_result["missing"].append(int(dlc))

            _set_download_state(appid, {
                "status": "done",
                "contentCheckResult": {
                    "workshop": workshop_result,
                    "dlc": dlc_result
                }
            })


        except Exception as exc:
            logger.error(f"LuaTools: Error checking lua for app {appid}: {exc}")
            _set_download_state(appid, {"status": "done"})

    try:
        os.remove(zip_path)
    except Exception:
        try:
            for _ in range(3):
                time.sleep(0.2)
                try:
                    os.remove(zip_path)
                    break
                except Exception:
                    continue
        except Exception:
            pass


def _is_download_cancelled(appid: int) -> bool:
    try:
        return _get_download_state(appid).get("status") == "cancelled"
    except Exception:
        return False


def _download_zip_for_app(appid: int):
    client = ensure_http_client("LuaTools: download")
    apis = load_api_manifest()
    if not apis:
        logger.warn("LuaTools: No enabled APIs in manifest")
        _set_download_state(appid, {"status": "failed", "error": "No APIs available"})
        return

    dest_root = ensure_temp_download_dir()
    dest_path = os.path.join(dest_root, f"{appid}.zip")
    _set_download_state(
        appid,
        {"status": "checking", "currentApi": None, "bytesRead": 0, "totalBytes": 0, "dest": dest_path, "apiErrors": {}},
    )

    # Get Morrenus API key for URL replacement
    morrenus_api_key = get_morrenus_api_key()

    for api in apis:
        name = api.get("name", "Unknown")
        template = api.get("url", "")
        success_code = int(api.get("success_code", 200))
        unavailable_code = int(api.get("unavailable_code", 404))

        # Check if URL requires Morrenus API key
        if "<moapikey>" in template:
            if not morrenus_api_key:
                # Skip this API silently if key is not set
                logger.log(f"LuaTools: Skipping API '{name}' - Morrenus API key not configured")
                continue
            # Replace the placeholder with the actual key
            template = template.replace("<moapikey>", morrenus_api_key)

        url = template.replace("<appid>", str(appid))
        _set_download_state(
            appid, {"status": "checking", "currentApi": name, "bytesRead": 0, "totalBytes": 0}
        )
        logger.log(f"LuaTools: Trying API '{name}'")
        try:
            headers = {"User-Agent": USER_AGENT}
            if _is_download_cancelled(appid):
                logger.log(f"LuaTools: Download cancelled before contacting API '{name}'")
                return
            with client.stream("GET", url, headers=headers, follow_redirects=True) as resp:
                code = resp.status_code
                logger.log(f"LuaTools: API '{name}' status={code}")
                if code == unavailable_code:
                    continue
                if code != success_code:
                    # Track error code for this API
                    state = _get_download_state(appid)
                    api_errors = state.get("apiErrors", {})
                    api_errors[name] = {"type": "error", "code": code}
                    _set_download_state(appid, {"apiErrors": api_errors})
                    continue
                total = int(resp.headers.get("Content-Length", "0") or "0")
                _set_download_state(appid, {"status": "downloading", "bytesRead": 0, "totalBytes": total})
                with open(dest_path, "wb") as output:
                    for chunk in resp.iter_bytes():
                        if not chunk:
                            continue
                        if _is_download_cancelled(appid):
                            logger.log(f"LuaTools: Download cancelled mid-stream for appid={appid}")
                            raise RuntimeError("cancelled")
                        output.write(chunk)
                        state = _get_download_state(appid)
                        read = int(state.get("bytesRead", 0)) + len(chunk)
                        _set_download_state(appid, {"bytesRead": read})
                        if _is_download_cancelled(appid):
                            logger.log(f"LuaTools: Download cancelled after writing chunk for appid={appid}")
                            raise RuntimeError("cancelled")
                logger.log(f"LuaTools: Download complete -> {dest_path}")

                if _is_download_cancelled(appid):
                    logger.log(f"LuaTools: Download marked cancelled after completion for appid={appid}")
                    raise RuntimeError("cancelled")

                try:
                    with open(dest_path, "rb") as fh:
                        magic = fh.read(4)
                        if magic not in (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08"):
                            file_size = os.path.getsize(dest_path)
                            with open(dest_path, "rb") as check_f:
                                preview = check_f.read(512)
                                content_preview = preview[:100].decode("utf-8", errors="ignore")
                            logger.warn(
                                f"LuaTools: API '{name}' returned non-zip file (magic={magic.hex()}, size={file_size}, preview={content_preview[:50]})"
                            )
                            try:
                                os.remove(dest_path)
                            except Exception:
                                pass
                            continue
                except FileNotFoundError:
                    logger.warn("LuaTools: Downloaded file not found after download")
                    continue
                except Exception as validation_exc:
                    logger.warn(f"LuaTools: File validation failed for API '{name}': {validation_exc}")
                    try:
                        os.remove(dest_path)
                    except Exception:
                        pass
                    continue

                try:
                    if _is_download_cancelled(appid):
                        logger.log(f"LuaTools: Processing aborted due to cancellation for appid={appid}")
                        raise RuntimeError("cancelled")
                    _set_download_state(appid, {"status": "processing"})
                    _process_and_install_lua(appid, dest_path)
                    if _is_download_cancelled(appid):
                        logger.log(f"LuaTools: Installation complete but marked cancelled for appid={appid}")
                        raise RuntimeError("cancelled")
                    try:
                        fetched_name = _fetch_app_name(appid) or f"UNKNOWN ({appid})"
                        _append_loaded_app(appid, fetched_name)
                        _log_appid_event(f"ADDED - {name}", appid, fetched_name)
                    except Exception:
                        pass
                    _set_download_state(appid, {"status": "done", "success": True, "api": name})
                    return
                except Exception as install_exc:
                    if isinstance(install_exc, RuntimeError) and str(install_exc) == "cancelled":
                        try:
                            if os.path.exists(dest_path):
                                os.remove(dest_path)
                        except Exception:
                            pass
                        logger.log(f"LuaTools: Cancelled download cleanup complete for appid={appid}")
                        return
                    logger.warn(f"LuaTools: Processing failed -> {install_exc}")
                    _set_download_state(
                        appid, {"status": "failed", "error": f"Processing failed: {install_exc}"}
                    )
                    try:
                        os.remove(dest_path)
                    except Exception:
                        pass
                    return
        except RuntimeError as cancel_exc:
            if str(cancel_exc) == "cancelled":
                try:
                    if os.path.exists(dest_path):
                        os.remove(dest_path)
                except Exception:
                    pass
                logger.log(f"LuaTools: Download cancelled and cleaned up for appid={appid}")
                return
            logger.warn(f"LuaTools: Runtime error during download for appid={appid}: {cancel_exc}")
            _set_download_state(appid, {"status": "failed", "error": str(cancel_exc)})
            return
        except Exception as err:
            logger.warn(f"LuaTools: API '{name}' failed with error: {err}")
            # Track error for this API - check if it's a timeout
            error_type = "timeout" if isinstance(err, (httpx.TimeoutException, httpx.ReadTimeout, httpx.ConnectTimeout)) else "error"
            error_code = None
            if isinstance(err, httpx.HTTPStatusError):
                error_code = err.response.status_code if err.response else None
            elif hasattr(err, "response") and err.response:
                error_code = err.response.status_code
            
            state = _get_download_state(appid)
            api_errors = state.get("apiErrors", {})
            if error_type == "timeout":
                api_errors[name] = {"type": "timeout"}
            else:
                api_errors[name] = {"type": "error", "code": error_code}
            _set_download_state(appid, {"apiErrors": api_errors})
            continue

    _set_download_state(appid, {"status": "failed", "error": "Not available on any API"})


def check_apis_for_app(appid: int) -> str:
    """Check all enabled APIs for a specific appid and return their availability."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})

    client = ensure_http_client("LuaTools: check_apis")
    apis = load_api_manifest()
    if not apis:
        return json.dumps({"success": True, "results": []})

    results = []
    morrenus_api_key = get_morrenus_api_key()

    fast_check_succeeded = False
    fast_check_data = {}
    
    try:
        fast_resp = client.get(
            f"http://167.235.229.108/check_apis?appid={appid}",
            headers={"User-Agent": "secretgoonpoon"},
            timeout=5,
            follow_redirects=True
        )
        if fast_resp.status_code == 200:
            fast_check_data = fast_resp.json()
            fast_check_succeeded = isinstance(fast_check_data, dict)
    except Exception as exc:
        logger.warn(f"LuaTools: Fast API check failed: {exc}")

    # Use a small timeout for availability check
    headers = {"User-Agent": USER_AGENT}
    
    for api in apis:
        name = api.get("name", "Unknown")
        template = api.get("url", "")
        success_code = int(api.get("success_code", 200))

        if "<moapikey>" in template:
            if not morrenus_api_key:
                continue
            template = template.replace("<moapikey>", morrenus_api_key)

        url = template.replace("<appid>", str(appid))
        available = False
        
        if fast_check_succeeded:
            check_key = "Sadie (Morrenus)" if name.lower() == "morrenus" else name
            if fast_check_data.get(check_key) == "available":
                available = True
        else:
            try:
                if name.lower() == "morrenus":
                    status_url = f"https://manifest.morrenus.xyz/api/v1/status/{appid}?api_key={morrenus_api_key}"
                    resp = client.get(status_url, headers=headers, follow_redirects=True, timeout=5)
                    if resp.status_code == success_code:
                        available = True
                else:
                    # We use HEAD for fast checking if possible, fallback to small GET
                    resp = client.head(url, headers=headers, follow_redirects=True, timeout=5)
                    if resp.status_code == success_code:
                        available = True
                    elif resp.status_code == 405: # Method Not Allowed - some APIs don't like HEAD
                        resp = client.get(url, headers=headers, follow_redirects=True, timeout=5)
                        if resp.status_code == success_code:
                            available = True
            except Exception:
                pass

        results.append({
            "name": name,
            "available": available,
            "url": url if available else None
        })

    return json.dumps({"success": True, "results": results})


def _download_zip_from_url(appid: int, url: str, api_name: str):
    """Internal worker to download from a specific URL."""
    client = ensure_http_client("LuaTools: download_direct")
    dest_root = ensure_temp_download_dir()
    dest_path = os.path.join(dest_root, f"{appid}.zip")
    
    _set_download_state(appid, {"status": "downloading", "currentApi": api_name, "bytesRead": 0, "totalBytes": 0, "dest": dest_path})

    try:
        headers = {"User-Agent": USER_AGENT}
        with client.stream("GET", url, headers=headers, follow_redirects=True) as resp:
            resp.raise_for_status()
            total = int(resp.headers.get("Content-Length", "0") or "0")
            _set_download_state(appid, {"totalBytes": total})
            
            with open(dest_path, "wb") as output:
                for chunk in resp.iter_bytes():
                    if _is_download_cancelled(appid):
                        raise RuntimeError("cancelled")
                    output.write(chunk)
                    state = _get_download_state(appid)
                    read = int(state.get("bytesRead", 0)) + len(chunk)
                    _set_download_state(appid, {"bytesRead": read})

        _set_download_state(appid, {"status": "processing"})
        _process_and_install_lua(appid, dest_path)
        
        fetched_name = _fetch_app_name(appid) or f"UNKNOWN ({appid})"
        _append_loaded_app(appid, fetched_name)
        _log_appid_event(f"ADDED - {api_name}", appid, fetched_name)
        
        _set_download_state(appid, {"status": "done", "success": True, "api": api_name})

    except Exception as exc:
        if str(exc) == "cancelled":
            if os.path.exists(dest_path):
                os.remove(dest_path)
            _set_download_state(appid, {"status": "cancelled", "error": "Cancelled by user"})
        else:
            logger.warn(f"LuaTools: _download_zip_from_url failed: {exc}")
            _set_download_state(appid, {"status": "failed", "error": str(exc)})


def start_add_via_luatools_from_url(appid: int, url: str, api_name: str) -> str:
    """Initiate a download from a specific URL selected by the user."""
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})

    _set_download_state(appid, {"status": "queued", "bytesRead": 0, "totalBytes": 0, "error": None})
    thread = threading.Thread(target=_download_zip_from_url, args=(appid, url, api_name), daemon=True)
    thread.start()
    return json.dumps({"success": True})


def start_add_via_luatools(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})

    logger.log(f"LuaTools: StartAddViaLuaTools appid={appid}")
    _set_download_state(appid, {"status": "queued", "bytesRead": 0, "totalBytes": 0})
    thread = threading.Thread(target=_download_zip_for_app, args=(appid,), daemon=True)
    thread.start()
    return json.dumps({"success": True})


def get_add_status(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})
    state = _get_download_state(appid)
    return json.dumps({"success": True, "state": state})


def read_loaded_apps() -> str:
    try:
        path = _loaded_apps_path()
        entries = []
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                for line in handle.read().splitlines():
                    if ":" in line:
                        appid_str, name = line.split(":", 1)
                        appid_str = appid_str.strip()
                        name = name.strip()
                        if appid_str.isdigit() and name:
                            entries.append({"appid": int(appid_str), "name": name})
        return json.dumps({"success": True, "apps": entries})
    except Exception as exc:
        return json.dumps({"success": False, "error": str(exc)})


def dismiss_loaded_apps() -> str:
    try:
        path = _loaded_apps_path()
        if os.path.exists(path):
            os.remove(path)
        return json.dumps({"success": True})
    except Exception as exc:
        return json.dumps({"success": False, "error": str(exc)})


def delete_luatools_for_app(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})

    base = detect_steam_install_path() or Millennium.steam_path()
    target_dir = os.path.join(base or "", "config", "stplug-in")
    paths = [
        os.path.join(target_dir, f"{appid}.lua"),
        os.path.join(target_dir, f"{appid}.lua.disabled"),
    ]
    deleted = []
    for path in paths:
        try:
            if os.path.exists(path):
                os.remove(path)
                deleted.append(path)
        except Exception as exc:
            logger.warn(f"LuaTools: Failed to delete {path}: {exc}")
    try:
        name = _get_loaded_app_name(appid) or _fetch_app_name(appid) or f"UNKNOWN ({appid})"
        _remove_loaded_app(appid)
        if deleted:
            _log_appid_event("REMOVED", appid, name)
    except Exception:
        pass
    return json.dumps({"success": True, "deleted": deleted, "count": len(deleted)})


def get_icon_data_url() -> str:
    try:
        steam_ui_path = os.path.join(Millennium.steam_path(), "steamui", WEBKIT_DIR_NAME)
        icon_path = os.path.join(steam_ui_path, WEB_UI_ICON_FILE)
        if not os.path.exists(icon_path):
            icon_path = public_path(WEB_UI_ICON_FILE)
        with open(icon_path, "rb") as handle:
            data = handle.read()
        b64 = base64.b64encode(data).decode("ascii")
        return json.dumps({"success": True, "dataUrl": f"data:image/png;base64,{b64}"})
    except Exception as exc:
        logger.warn(f"LuaTools: GetIconDataUrl failed: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


def has_luatools_for_app(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})
    exists = has_lua_for_app(appid)
    return json.dumps({"success": True, "exists": exists})


def cancel_add_via_luatools(appid: int) -> str:
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Invalid appid"})

    state = _get_download_state(appid)
    if not state or state.get("status") in {"done", "failed"}:
        return json.dumps({"success": True, "message": "Nothing to cancel"})

    _set_download_state(appid, {"status": "cancelled", "error": "Cancelled by user"})
    logger.log(f"LuaTools: Cancellation requested for appid={appid}")
    return json.dumps({"success": True})


def get_installed_lua_scripts() -> str:
    """Get list of all installed Lua scripts from stplug-in directory."""
    try:
        # Pre-load app names cache from file to avoid API calls
        _preload_app_names_cache()

        base_path = detect_steam_install_path() or Millennium.steam_path()
        if not base_path:
            return json.dumps({"success": False, "error": "Could not find Steam installation path"})

        target_dir = os.path.join(base_path, "config", "stplug-in")
        if not os.path.exists(target_dir):
            return json.dumps({"success": True, "scripts": []})

        installed_scripts = []

        try:
            for filename in os.listdir(target_dir):
                # Match both enabled (.lua) and disabled (.lua.disabled) scripts
                if filename.endswith(".lua") or filename.endswith(".lua.disabled"):
                    try:
                        # Extract appid from filename
                        appid_str = filename.replace(".lua.disabled", "").replace(".lua", "")
                        appid = int(appid_str)

                        # Check if it's disabled
                        is_disabled = filename.endswith(".lua.disabled")

                        # Try to get game name from cache (no API calls during listing)
                        game_name = ""
                        with APP_NAME_CACHE_LOCK:
                            game_name = APP_NAME_CACHE.get(appid, "")

                        # Fallback to loaded_apps file if not in cache
                        # (_get_loaded_app_name also checks applist as fallback)
                        if not game_name:
                            game_name = _get_loaded_app_name(appid)

                        # Only use "Unknown Game" as last resort - don't fetch from API
                        if not game_name:
                            game_name = f"Unknown Game ({appid})"

                        # Get file stats
                        file_path = os.path.join(target_dir, filename)
                        file_stat = os.stat(file_path)
                        file_size = file_stat.st_size

                        # Format date
                        modified_time = datetime.datetime.fromtimestamp(file_stat.st_mtime)
                        formatted_date = modified_time.strftime("%Y-%m-%d %H:%M:%S")

                        script_info = {
                            "appid": appid,
                            "gameName": game_name,
                            "filename": filename,
                            "isDisabled": is_disabled,
                            "fileSize": file_size,
                            "modifiedDate": formatted_date,
                            "path": file_path
                        }

                        installed_scripts.append(script_info)

                    except ValueError:
                        # Not a numeric filename, skip
                        continue
                    except Exception as exc:
                        logger.warn(f"LuaTools: Failed to process Lua file {filename}: {exc}")
                        continue

        except Exception as exc:
            logger.warn(f"LuaTools: Failed to scan stplug-in directory: {exc}")
            return json.dumps({"success": False, "error": f"Failed to scan directory: {str(exc)}"})

        # Sort by appid
        installed_scripts.sort(key=lambda x: x["appid"])

        return json.dumps({"success": True, "scripts": installed_scripts})

    except Exception as exc:
        logger.warn(f"LuaTools: Failed to get installed Lua scripts: {exc}")
        return json.dumps({"success": False, "error": str(exc)})


__all__ = [
    "cancel_add_via_luatools",
    "delete_luatools_for_app",
    "dismiss_loaded_apps",
    "fetch_app_name",
    "fetch_app_info",
    "get_add_status",
    "get_games_database",
    "get_icon_data_url",
    "get_installed_lua_scripts",
    "has_luatools_for_app",
    "init_applist",
    "init_games_db",
    "read_loaded_apps",
    "start_add_via_luatools",
    "check_apis_for_app",
    "start_add_via_luatools_from_url",
]
